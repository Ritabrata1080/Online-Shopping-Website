package com.abhiram;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class login extends HttpServlet {

    private static final long serialVersionUID = 2161581691453946987L;

    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String cssTag = "<link rel='stylesheet' type='text/css' href='./styling/style.css'>";
        out.println("<head><title>Servlet Home Page</title>" + cssTag + "</head>");
        out.println("<body>");

        try {
            String name = request.getParameter("user");

            String pword = request.getParameter("pass");
            String mail = request.getParameter("email");
            out.println("<body>");
            String info = name;
            String info1 = pword;
            String info2 = mail;
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/database2", "root", "root");
            System.out.println("Connection established successfully"); //
            System.out.println("Inserting into database...");
            Statement stmt = con.createStatement();
            stmt.executeUpdate(
                    "insert into demo(name, password,email) values('" + info + "', '" + info1 + "', '" + info2 + "')");
            out.print("<div id=logdiv>");
            out.print("<h1>Login Form</h1>");
            out.println("<form action='api' method='POST'>");
            out.println("<label>Name </label><input type='text' name='namelog' required>");
            out.println("<label>Password </label><input type='password' name='logpass' required><br><br>");
            out.println("<input type='submit' value='Send' id='sub'>");
            out.println("</form>");
            out.println("<form action='admpanel' method='POST'>");
            out.println("<label>Name </label><input type='text' name='adminname' required>");
            out.println("<label>Password </label><input type='password' name='adminpass' required>");
            out.println("<input type='submit' value='Go to Admin Panel' id='adminbtn'>");
            out.println("</form>");
            out.println("</div>");
            out.println("</body>");

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}
