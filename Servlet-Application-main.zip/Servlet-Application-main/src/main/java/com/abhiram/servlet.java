package com.abhiram;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.http.HttpResponse.ResponseInfo;

import javax.security.auth.callback.NameCallback;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.ComboBoxEditor;

import com.mysql.cj.protocol.Resultset;

import java.sql.*;

public class servlet extends HttpServlet {

    private static final long serialVersionUID = 2161581691453946987L;

    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /*
         * Usage of some methods in HttpServletResponse and ServletResponse interfaces
         */
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String cssTag = "<link rel='stylesheet' type='text/css' href='./styling/style.css'>";
        out.println("<head><title>Servlet Home Page</title>" + cssTag + "</head>");
        out.println("<body>");

        try {
            String name = request.getParameter("namelog");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/database2", "root", "root");
            Statement smt = con.createStatement();

            String namelogin = request.getParameter("namelog");
            String passlogin = request.getParameter("logpass");
            ResultSet r = smt
                    .executeQuery("select * from demo where name='" + namelogin + "' and password='" + passlogin + "'");

            ServletContext context = getServletContext();
            context.setAttribute("currentuser", namelogin);

            String namecheck[] = new String[20];
            String password[] = new String[20];
            String email[] = new String[20];
            int z = 1;
            while (r.next()) {

                z = 0;
            }
            if (z == 1) {
                out.println("<h2>Failed to Login</h2>");
            } else {
                out.println("<h2>Login Success!</h2>");
                out.println("<form action='cart' method='POST'>");
                out.println("<input type='submit' value='Go to Cart' id='cartbtn'>");
                out.println("</form>");
            }
            out.println("</body>");
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}

// "select * from demo where name= "+name