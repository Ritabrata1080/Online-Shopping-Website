package com.abhiram;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class admpanel extends HttpServlet {

    private static final long serialVersionUID = 2161581691453946987L;

    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /*
         * Usage of some methods in HttpServletResponse and ServletResponse interfaces
         */
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String cssTag = "<link rel='stylesheet' type='text/css' href='./styling/style.css'>";
        out.println("<head><title>Admin Login</title>" + cssTag + "</head>");
        out.println("<body>");
        try {
            String admin = request.getParameter("adminname");
            String adminp = request.getParameter("adminpass");
            if (admin.equals("Admin") && adminp.equals("Secret123")) {
                out.println("<div id='deleteform'>");
                out.println("<h1>Welcome to admin page</h1>");
                out.println("<form action='delete' method='POST'>");
                out.println("<h3>Delete Product<h3>");
                out.println("<label>Enter Product id : </label><input type='text' name='proid' required>");
                out.println("<input type='submit' value='Delete Item' id='delbtn'>");
                out.println("</div>");
                out.println("</form>");
                out.println("<hr width=100%>");
                out.println("<div id='updateform'>");
                out.println("<form action='update' method='POST'>");

                out.println("<h3>Update Product<h3>");
                out.println("<label>Enter Product id : </label><input type='text' name='proidup' required>");
                out.println("<label>Enter Product Price : </label><input type='text' name='proprice' required>");
                out.println("<input type='submit' value='Update Item' id='updbtn'>");
                out.println("</form>");
            } else {
                out.println("<h1>Only admins are allowed</h1>");
                out.println("<form action='login' method='POST'>");
                out.println("<input type='submit' value='Go Back' id='retadm'>");
                out.println("</form>");
            }
            out.println("</div>");
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            out.close();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}