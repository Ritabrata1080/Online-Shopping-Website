package com.abhiram;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

public class delete extends HttpServlet {

    private static final long serialVersionUID = 2161581691453946987L;

    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /*
         * Usage of some methods in HttpServletResponse and ServletResponse interfaces
         */
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        out.println("<head><title>Delete</title></head>");
        out.println("<body>");

        try {
            out.println("<form action='admpanel' method='POST'>");
            out.println("<input type='submit' value='Go back to admin page' id='backadm'>");
            out.println("</form>");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/producttable", "root", "root");
            Statement smt = con.createStatement();
            String pidnum = request.getParameter("proid");
            smt.executeUpdate("delete from productshow where pid='" + pidnum + "'");
            out.println("<h2>Item deleted Successfully</h2>");

        } catch (Exception e) {
            System.out.println(e);
        } finally {
            out.close();
        }

    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.print("test");
        processRequest(request, response);
    }
}
