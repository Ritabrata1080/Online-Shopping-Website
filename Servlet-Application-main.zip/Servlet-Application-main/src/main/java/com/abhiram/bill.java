package com.abhiram;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.xdevapi.Result;

import java.sql.*;

public class bill extends HttpServlet {

    private static final long serialVersionUID = 2161581691453946987L;

    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /*
         * Usage of some methods in HttpServletResponse and ServletResponse interfaces
         */
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String cssTag = "<link rel='stylesheet' type='text/css' href='./styling/style.css'>";
        out.println("<head><title>Servlet Home Page</title>" + cssTag + "</head>");
        out.println("<body>");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/producttable", "root", "root");
            Statement smt = con.createStatement();
            ResultSet rset = smt.executeQuery("select * from productshow");
            int q = 0;
            String productprice[] = new String[30];
            while (rset.next()) {
                productprice[q] = rset.getString(3);
                q++;
            }
            String cost1 = request.getParameter("s1");
            String cost2 = request.getParameter("s2");
            String cost3 = request.getParameter("s3");
            String cost4 = request.getParameter("s4");
            int totalcost1 = 0, totalcost2 = 0, totalcost3 = 0, totalcost4 = 0;
            if (!cost1.equals("")) {
                totalcost1 = Integer.parseInt(cost1) * Integer.parseInt(productprice[0]);
            }

            if (!cost2.equals("")) {
                totalcost2 = Integer.parseInt(cost2) * Integer.parseInt(productprice[1]);
            }

            if (!cost3.equals("")) {
                totalcost3 = Integer.parseInt(cost3) * Integer.parseInt(productprice[2]);
            }

            if (!cost4.equals("")) {
                totalcost4 = Integer.parseInt(cost4) * Integer.parseInt(productprice[3]);
            }
            int finalCost = totalcost1 + totalcost2 + totalcost3 + totalcost4;
            String billfin = String.valueOf(finalCost);
            out.print("<h2 id='findis'>Your total bill is : " + finalCost + "</h2>");
            out.println("<hr width=100%>");
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/billtable", "root", "root");
            Statement smt1 = con1.createStatement();
            smt1.executeUpdate("insert into showbill(Bill) values('" + billfin + "') ");
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            out.close();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}