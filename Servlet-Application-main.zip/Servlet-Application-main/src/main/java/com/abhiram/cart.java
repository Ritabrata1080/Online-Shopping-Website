package com.abhiram;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.xdevapi.Result;

import java.sql.*;

public class cart extends HttpServlet {

    private static final long serialVersionUID = 2161581691453946987L;

    public void processRequest(HttpServletRequest request, HttpServletResponse response) throws IOException {
        /*
         * Usage of some methods in HttpServletResponse and ServletResponse interfaces
         */
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        String cssTag = "<link rel='stylesheet' type='text/css' href='./styling/style.css'>";
        out.println("<head><title>Servlet Home Page</title>" + cssTag + "</head>");
        out.println("<body>");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/producttable", "root", "root");
            Statement smt = con.createStatement();
            ResultSet rset = smt.executeQuery("select * from productshow");
            int q = 0;
            String productid[] = new String[30];
            String productname[] = new String[30];
            String productprice[] = new String[30];
            while (rset.next()) {
                productid[q] = rset.getString(1);
                productname[q] = rset.getString(2);
                productprice[q] = rset.getString(3);
                q++;
            }

            out.print("<h1> Welcome to cart</h2>");
            out.print("<form action='bill' method='POST'> ");
            out.println("<label>Item : " + productname[0] + "</label><br>");
            out.println("<label>Select Quantity : </label><input type='number' name='s1' value='0'><br>");
            out.println("<label>Price " + productprice[0] + "</label><br><br>");

            out.println("<label>Item : " + productname[1] + "</label><br>");
            out.println("<label>Select Quantity : </label><input type='number' name='s2' value='0'><br>");
            out.println("<label>Price " + productprice[1] + "</label><br><br>");

            out.println("<label>Item : " + productname[2] + "</label><br>");
            out.println("<label>Select Quantity : </label><input type='number' name='s3' value='0'><br>");
            out.println("<label>Price " + productprice[2] + "</label><br><br>");

            out.println("<label>Item : " + productname[3] + "</label><br>");
            out.println("<label>Select Quantity : </label><input type='number' name='s4' value='0'><br>");
            out.println("<label>Price " + productprice[3] + "</label>");

            out.println("<input type='submit' value='Generate Bill' id='genbill'>");
            out.println("</form>");
            out.println("<hr width=100%>");
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            out.close();
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request, response);
    }
}