# Java Web Application
* Developed using Maven
* Uses Apache TomCat for deployment and testing
* Worked in Microsoft VS Code 